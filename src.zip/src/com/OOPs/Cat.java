package com.OOPs;

public class Cat extends Animal {

	public void meow() {

		System.out.println("meowing...");

	}
}
